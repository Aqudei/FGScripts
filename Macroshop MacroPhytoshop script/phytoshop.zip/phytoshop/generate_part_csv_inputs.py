from phytoshop_gui_settings import *
import tkinter as tk
from tkinter import font

class GeneratePartCSVInputs(tk.Toplevel):
    def __init__(self, master):
        tk.Toplevel.__init__(self, master)
        self.parent = master
        self.title("Inputs for Part CSV Generation")
        self.bounds = {}
        self.messages = {}
        self.labels = ["1stEmpty",
                       "TmenuOrder",
                       "SortOrder",
                       "TmenuFrame"]
        self.create_widgets()
        
    def quit(self):
        self.save_entries()
        for base, sequence in self.parent.get_mask_sequences().items():
            print(sequence.get_part_params())
        self.destroy()

    def save_entries(self):
        index = 0
        for base, sequence in self.parent.get_mask_sequences().items():
            values = []
            for i in range(index, index + len(self.labels)):
                values.append(self.entries[i].get())
            sequence.set_part_params(values)
            index += len(self.labels)
            
    def create_widgets(self):
        row = 0
        col = 1
        for label in self.labels:
            tk.Label(self, font=self.parent.custom_font,
                     text=label).grid(row=row,
                                      column=col,
                                      sticky=tk.W,
                                      padx=self.parent.get_padding(),
                                      pady=self.parent.get_padding())
            col +=1
        # Generate table entries
        self.entries = []
        for base, sequence in self.parent.get_mask_sequences().items():
            row += 1
            col = 0
            tk.Label(self, font=self.parent.custom_font,
                     text=base).grid(row=row,
                                     column=col,
                                     sticky=tk.W,
                                     padx=self.parent.get_padding(),
                                     pady=self.parent.get_padding())
            # Entries
            col = 1
            for label in self.labels:
                if label == "1stEmpty":
                    entry = tk.IntVar()
                    self.entries.append(entry)
                    tk.Checkbutton(self, font=self.parent.custom_font,
                                   text="",
                                   variable=entry).grid(row=row,
                                                        column=col,
                                                        padx=self.parent.get_padding(),
                                                        pady=self.parent.get_padding())
                else:
                    entry = tk.StringVar()
                    self.entries.append(entry)
                    tk.Entry(self,
                             font=self.parent.custom_font,
                             textvariable=entry).grid(row=row,
                                                      column=col,
                                                      padx=self.parent.get_padding(),
                                                      pady=self.parent.get_padding())
                
                col += 1


        # OK button
        row += 1
        tk.Button(self, font=self.parent.custom_font,
                  text="OK",
                  command=self.quit).grid(row=row,
                                          column=1,
                                          padx=self.parent.get_padding(),
                                          pady=self.parent.get_padding())
        
