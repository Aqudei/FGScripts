PADDING = 5
GUI_SAVED_SETTINGS_FILE = ".phytoshop_gui_saved_settings"
MACRO_GUI_SAVED_SETTINGS_FILE = ".macrophytoshop_gui_saved_settings"
FONT_SIZE = 12
FONT_FAMILY = "Arial"
MAIN_WINDOW_WIDTH = 400
MAIN_WINDOW_HEIGHT = 500

