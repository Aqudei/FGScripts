from phytoshop_gui_settings import *
from sequence import Sequence
from crop_analysis_results import CropAnalysisResults
from resize_summary import ResizeSummary
from generate_part_csv_inputs import GeneratePartCSVInputs
from zipfile import ZipFile
import tkinter as tk
import numpy as np
from tkinter import messagebox
from tkinter import font
from scipy import misc
import logging
import pickle
import sys
import shutil
import os
import re
import glob


class MacroPhytoshop(tk.Frame):
    def __init__(self, master=None):
        tk.Frame.__init__(self, master)
        self.parent = master
        self.parent.title("Macro Phytoshop")
        self.custom_font = font.Font(family=FONT_FAMILY, size=FONT_SIZE)
        self.custom_font2 = font.Font(family=FONT_FAMILY, size=int(0.7*FONT_SIZE))
        self.load_variables()
        self.create_widgets()
        self.define_bindings()


    def define_bindings(self):
        # Bind window closing event
        self.parent.protocol("WM_DELETE_WINDOW", self.on_closing)

    def on_closing(self):
        # Save settings
        if self.validate_dir(self.directory_entry.get()):
            self.set_directory(self.directory_entry.get())
        #if self.validate_dir(self.directory2_entry.get()):
        #    self.set_directory2(self.directory2_entry.get())
        # self.set_base_name(self.base_name_entry.get())
        # self.set_mask_name(self.mask_name_entry.get())
        # self.set_output_filename(self.output_filename_entry.get())
        # self.set_start_frame(self.start_frame_entry.get())
        # self.set_crop_override(self.crop_override_entry.get())

        self.save_variables()
        self.parent.destroy()

    def load_variables(self):
        self.init_sequences()
        try:
            #f = open(os.path.join(os.environ['HOME'], MACRO_GUI_SAVED_SETTINGS_FILE), 'rb' )
            f = open(MACRO_GUI_SAVED_SETTINGS_FILE, 'rb' )
            settings = pickle.load(f)
            f.close()
            self.set_directory(settings['directory'])
            self.set_geometry(settings['geometry'])
            self.set_model_name('')
            self.set_output_dir('../..')
        except:
            print("could not load variables")
            self.initialize_saveable_variables()
    
    def save_variables(self):
        settings = {}
        settings['directory'] = self.get_directory()
        settings['geometry'] = self.get_geometry()
        try:
            #f = open(os.path.join(os.environ['HOME'], MACRO_GUI_SAVED_SETTINGS_FILE), 'wb' )
            f = open(MACRO_GUI_SAVED_SETTINGS_FILE, 'wb' )
            pickle.dump( settings, f )
            f.close()
        except:
            logging.warning("Could not save GUI settings")
            
    def initialize_saveable_variables(self):
        self.set_directory(".")
        # Default size
        sw = self.get_screen_width()
        sh = self.get_screen_height()
        # Put to the middle of the screen by default
        x = int((sw - MAIN_WINDOW_WIDTH) / 2)
        y = int((sh - MAIN_WINDOW_HEIGHT) / 2)
        geometry = "%dx%d+%d+%d" % (MAIN_WINDOW_WIDTH,
                                    MAIN_WINDOW_HEIGHT,
                                    x, y)

        self.parent.geometry(geometry)
        self.set_padding(PADDING)
        
    def get_window_x(self):
        return self.parent.winfo_x()
        
    def get_window_y(self):
        return self.parent.winfo_y()
        
    def get_window_width(self):
        return self.parent.winfo_width()

    def get_window_height(self):
        return self.parent.winfo_height()

    def get_screen_width(self):
        return self.parent.winfo_screenwidth()

    def get_screen_height(self):
        return self.parent.winfo_screenheight()

    def get_geometry(self):
        return self.parent.geometry()

    def set_geometry(self, geometry):
        self.parent.geometry(geometry)

    def set_padding(self, padding):
        self.padding = PADDING

    def get_padding(self):
        self.padding = PADDING
        return self.padding

    def get_directory_entry(self):
        return self.directory_entry.get()

    def set_directory_entry(self, text):
        self.directory_entry.set(text)

    def set_directory(self, dir):
        self.directory = dir

    def get_directory(self):
        return self.directory

    def set_output_dir(self, directory):
        self.output_dir = directory

    def get_output_dir(self):
        return self.output_dir
    
    def set_directory_message(self, text, color):
        self.directory_message['text'] = text
        self.directory_message['foreground'] = color

    def on_directory_change(self, *args):
        self.update_gui()
        if self.validate_dir(self.directory_entry.get()):
            self.set_directory(self.directory_entry.get())
            
    def update_directory_message(self):
        if self.validate_dir(self.directory_entry.get()):
            self.set_directory_message("OK", "green")
        else: self.set_directory_message("Invalid dir", "red")

    def validate_dir(self, dir):
        # Validate selected directory as a proper dir
        if not dir:
            return False
        if os.path.isdir(dir):
            return True
        else:
            return False

    def validate_dir_file(self, dir, file):
        # Validate selected file and directory as a proper file
        if not self.validate_dir(dir):
            return False
        if os.path.isfile(os.path.join(dir, file)):
            return True
        else:
            return False

        
    def create_widgets(self):
        row = 0
        # Row 0, Input folder
        tk.Label(self.parent, font=self.custom_font,
                 text="Input directory:").grid(row=row, sticky=tk.E,
                                            padx=self.get_padding(),
                                              pady=self.get_padding())

        self.directory_entry = tk.StringVar()
        # Initialize value
        self.set_directory_entry(self.get_directory())
        
        self.directory_entry.trace("w", self.on_directory_change)
        tk.Entry(self.parent,
                 font=self.custom_font,
                 textvariable=self.directory_entry).grid(row=row,
                                                         column=1,
                                                         padx=self.get_padding(),
                                                         pady=self.get_padding())
        
        self.directory_message = tk.Label(self.parent, font=self.custom_font2, text="")
        self.directory_message.grid(row=row,
                                    column=2,
                                    sticky=tk.W,
                                    padx=self.get_padding(),
                                    pady=self.get_padding())

        # Initialize dir message value
        self.update_directory_message()

        row +=1
        # Row 1, button "run macro 1"
        tk.Button(self.parent, font=self.custom_font,
                  text="RUN Macro 1",
                  command=self.run_macro1).grid(row=row,
                                                     column=1,
                                                     padx=self.get_padding(),
                                                     pady=self.get_padding())
        
        
        self.script1_message = tk.Label(self.parent,
                                        font=self.custom_font2, text="")
        self.script1_message.grid(row=row,column=2,sticky=tk.W,
                                  padx=self.get_padding(),
                                  pady=self.get_padding())


        row +=1
        # Row 2, button "edit crop bounds"
        tk.Button(self.parent, font=self.custom_font,
                  text="Edit crop bounds",
                  command=self.edit_crop_bounds).grid(row=row,
                                                      column=1,
                                                      padx=self.get_padding(),
                                                      pady=self.get_padding())
        
        row +=1
        # Row 3, button "run macro 2"
        tk.Button(self.parent, font=self.custom_font,
                  text="Run macro 2",
                  command=self.run_macro2).grid(row=row,
                                                column=1,
                                                padx=self.get_padding(),
                                                pady=self.get_padding())
        

        self.script2_message = tk.Label(self.parent,
                                        font=self.custom_font2, text="")
        self.script2_message.grid(row=row,column=2,sticky=tk.W,
                                  padx=self.get_padding(),
                                  pady=self.get_padding())

        row +=1
        # Row 4, input ModelName
        tk.Label(self.parent, font=self.custom_font,
                 text="ModelName:").grid(row=row, sticky=tk.E,
                                            padx=self.get_padding(),
                                              pady=self.get_padding())

        self.model_name_entry = tk.StringVar()
        
        self.model_name_entry.trace("w", self.on_model_name_change)
        tk.Entry(self.parent,
                 font=self.custom_font,
                 textvariable=self.model_name_entry).grid(row=row,
                                                          column=1,
                                                          padx=self.get_padding(),
                                                          pady=self.get_padding())
        
        row +=1
        # Row 5, button "read data from crop_report"
        tk.Button(self.parent, font=self.custom_font,
                  text="Read data from crop_report.csv",
                  command=self.read_sequences).grid(row=row,
                                                       column=1,
                                                       padx=self.get_padding(),
                                                       pady=self.get_padding())

        self.script3_message = tk.Label(self.parent,
                                        font=self.custom_font2, text="")
        self.script3_message.grid(row=row,column=2,sticky=tk.W,
                                  padx=self.get_padding(),
                                  pady=self.get_padding())

        row +=1
        # Row 6, button "generate part csv"
        tk.Button(self.parent, font=self.custom_font,
                  text="Generate Part CSV (Part A)",
                  command=self.generate_part_csv_part_a).grid(row=row,
                                                       column=1,
                                                       padx=self.get_padding(),
                                                       pady=self.get_padding())
        

        
        self.script4_message = tk.Label(self.parent,
                                        font=self.custom_font2, text="")
        self.script4_message.grid(row=row,column=2,sticky=tk.W,
                                  padx=self.get_padding(),
                                  pady=self.get_padding())
        

        row +=1
        # Row 6, button "generate part csv"
        tk.Button(self.parent, font=self.custom_font,
                  text="Generate Part CSV (Part B)",
                  command=self.generate_part_csv_part_b).grid(row=row,
                                                       column=1,
                                                       padx=self.get_padding(),
                                                       pady=self.get_padding())
        

        
        self.script5_message = tk.Label(self.parent,
                                        font=self.custom_font2, text="")
        self.script5_message.grid(row=row,column=2,sticky=tk.W,
                                  padx=self.get_padding(),
                                  pady=self.get_padding())
        


        
        row +=1
        tk.Label(self.parent, font=self.custom_font,
                 text="Resample interpolation method:").grid(row=row, sticky=tk.E,
                                                    padx=self.get_padding(),
                                                    pady=self.get_padding())
        self.interpolation_method = tk.StringVar()
        self.interpolation_method.set("lanczos") # default value
        tk.OptionMenu(self.parent,
                      self.interpolation_method,
                      "lanczos",
                      "nearest",
                      "bilinear",
                      "bicubic",
                      "cubic").grid(row=row,
                                    column=1,
                                    padx=self.get_padding(),
                                    pady=self.get_padding())

        row +=1
        # Row 6, button "generate part csv"
        tk.Button(self.parent, font=self.custom_font,
                  text="Generate TMenu overlay images",
                  command=self.generate_tmenu_buttons).grid(row=row,
                                                       column=1,
                                                       padx=self.get_padding(),
                                                       pady=self.get_padding())
        
        self.script6_message = tk.Label(self.parent,
                                        font=self.custom_font2, text="")
        self.script6_message.grid(row=row,column=2,sticky=tk.W,
                                  padx=self.get_padding(),
                                  pady=self.get_padding())
        
        row +=1
        # Row 6, button "generate part csv"
        tk.Button(self.parent, font=self.custom_font,
                  text="Glue overlay images on TMenu buttons",
                  command=self.glue_overlays).grid(row=row,
                                                       column=1,
                                                       padx=self.get_padding(),
                                                       pady=self.get_padding())
        
        self.script7_message = tk.Label(self.parent,
                                        font=self.custom_font2, text="")
        self.script7_message.grid(row=row,column=2,sticky=tk.W,
                                  padx=self.get_padding(),
                                  pady=self.get_padding())
        
        row +=1
        # Row 6, button "generate part csv"
        tk.Button(self.parent, font=self.custom_font,
                  text="Resize images",
                  command=self.resize_images).grid(row=row,
                                                       column=1,
                                                       padx=self.get_padding(),
                                                       pady=self.get_padding())
        
        self.script8_message = tk.Label(self.parent,
                                        font=self.custom_font2, text="")
        self.script8_message.grid(row=row,column=2,sticky=tk.W,
                                  padx=self.get_padding(),
                                  pady=self.get_padding())
        

    def resize_images(self):
        ResizeSummary(self)

        
    def on_model_name_change(self, *args):
        self.set_model_name(self.model_name_entry.get())

    def set_model_name(self, name):
        self.model_name = name

    def get_model_name(self):
        return self.model_name
        
    def edit_crop_bounds(self):
        if len(self.get_mask_sequences()):
            CropAnalysisResults(self)
            
    def init_sequences(self):
        self.mask_sequences = {}
        self.source_sequences = {}

    def get_mask_sequences(self):
        return self.mask_sequences
    
    def get_mask_sequence(self, base):
        return self.get_mask_sequences()[base]
    
    def add_mask_sequence(self, sequence):
        if not sequence.get_base() in self.get_mask_sequences():
            self.get_mask_sequences()[sequence.get_base()] = sequence
            
    def mask_sequence_exists(self, base):
        return base in self.get_mask_sequences()
    
    def get_source_sequences(self):
        return self.source_sequences
    
    def get_source_sequence(self, base):
        return self.get_source_sequences()[base]
    
    def add_source_sequence(self, sequence):
        if not sequence.get_base() in self.get_source_sequences():
            self.get_source_sequences()[sequence.get_base()] = sequence
            
    def source_sequence_exists(self, base):
        return base in self.get_source_sequences()
    
    def generate_part_csv_part_a(self):
        self.set_script4_message("Running", "green")
        GeneratePartCSVInputs(self)
        self.set_script4_message("Done", "green")
        
    def generate_part_csv_part_b(self):
        self.set_script5_message("Running", "green")
        self.copy_model_folder_structure()
        self.generate_part_csv()
        self.generate_features_csv()
        self.set_script5_message("Done", "green")

    def generate_tmenu_buttons(self):
        self.set_script6_message("Running", "green")
        tmenu_base_path = os.path.join(self.get_output_dir(),
                                       self.get_model_name(),
                                       self.get_model_name() + '_UI',
                                       'TMenu')
        try:
            tmenu_base = misc.imread(os.path.join(tmenu_base_path,
                                                  'TMenu.png'))
        except:
            self.set_script6_message("Error, could not open image", "red")
            return
        
        for base, sequence in self.get_mask_sequences().items():
            # Get the image
            self.set_script6_message("Generating TMenu {}".format(base), "green")
            image_path =  os.path.join(self.get_directory(),
                                       base,
                                       base + '_Clay1.'+str(sequence.get_part_params()[3])+'.png')
            print (image_path)
            try:
                overlay = misc.imread(image_path)
            except:
                self.set_script6_message("Error, could not open image", "red")
                return

            # Let's do the overlay
            # Crop overlay
            nonzeros = np.nonzero(overlay[:,:,3])
            if len(nonzeros[0]) == 0 or len(nonzeros[1]) == 0:
                cropped = overlay.copy()
            else:
                row_start = min(nonzeros[0])
                col_start = min(nonzeros[1])
                row_end = max(nonzeros[0])
                col_end = max(nonzeros[1])
                cropped = overlay[row_start:row_end,col_start:col_end]

            # Resize overlay
            scale_factor = 0.62*np.min([tmenu_base.shape[0]/(1.0*cropped.shape[0]),
                                        tmenu_base.shape[1]/(1.0*cropped.shape[1])])
            cropped = misc.imresize(cropped, scale_factor, interp=self.interpolation_method.get())
            zeros = np.zeros(np.shape(tmenu_base))
            # Padding
            padding_top = int((tmenu_base.shape[0] - cropped.shape[0])/2)
            padding_left = int((tmenu_base.shape[1] - cropped.shape[1])/2)
            zeros[padding_top:padding_top + cropped.shape[0],
                  padding_left:padding_left + cropped.shape[1],
                  :] = cropped


            # Contrast to 0.25
            zeros[:,:,0:3] = 0.25*zeros[:,:,0:3]
            path =  os.path.join(self.get_directory(),
                                 base,
                                 base + '_tmenu_overlay.png')
            misc.imsave(path, zeros)


            
        self.set_script6_message("Done", "green")

    def glue_overlays(self):
        self.set_script7_message("Running", "green")
        tmenu_base_path = os.path.join(self.get_output_dir(),
                                       self.get_model_name(),
                                       self.get_model_name() + '_UI',
                                       'TMenu')
        try:
            tmenu_base = misc.imread(os.path.join(tmenu_base_path,
                                                  'TMenu.png'))
        except:
            self.set_script6_message("Error, could not open image", "red")
                
        
        for base, sequence in self.get_mask_sequences().items():
            path =  os.path.join(self.get_directory(),
                                 base,
                                 base + '_tmenu_overlay.png')
            overlay = misc.imread(path)
            tmenu_button = tmenu_base*np.ones(tmenu_base.shape, np.float32)
            overlay = overlay*np.ones(overlay.shape, np.float32)

            pixels = overlay[:,:,3]>0
            # The actual overlay
            tmenu_button[pixels,0] = tmenu_button[pixels,0]*(255-overlay[pixels,3])/255.0  + overlay[pixels,0]*overlay[pixels,3]/255.0
            tmenu_button[pixels,1] = tmenu_button[pixels,1]*(255-overlay[pixels,3])/255.0  + overlay[pixels,1]*overlay[pixels,3]/255.0
            tmenu_button[pixels,2] = tmenu_button[pixels,2]*(255-overlay[pixels,3])/255.0  + overlay[pixels,2]*overlay[pixels,3]/255.0
            
            print(os.path.join(tmenu_base_path,
                                     'TMenu_{}.png'.format(base)))
            
            misc.imsave(os.path.join(tmenu_base_path,
                                     'TMenu_{}.png'.format(base)), tmenu_button)
        self.set_script7_message("Done", "green")
        
    def generate_features_csv(self):
        with open('features_csv_base.csv', 'r') as f:
            start = f.read()
        with open('features_csv_end.csv', 'r') as f:
            end = f.read()
        with open('features_csv_line.csv', 'r') as f:
            orig_line = f.read()

        lines = ''
        for base, sequence in self.get_mask_sequences().items():
            line = orig_line
            line = line.replace('[Part]', str(base))
            lines += line

        # Glue the parts together
        output = start + lines + end
        file_out =  os.path.join(self.get_output_dir(),
                                 self.get_model_name(),
                                 self.get_model_name() + '_Features.csv')
        with open(file_out, 'w') as f:
            f.write(output)
            
    def generate_part_csv(self):
        with open('part_csv_base.csv', 'r') as f:
            start = f.read()
        with open('part_csv_end.csv', 'r') as f:
            end = f.read()
        with open('part_csv_line.csv', 'r') as f:
            orig_line = f.read()
        with open('part_csv_1stEmpty_line.csv', 'r') as f:
            orig_1stEmpty_line = f.read()

        lines = ''
        largest_order = 0
        for base, sequence in self.get_mask_sequences().items():
            # Update largest order
            try:
                if int(sequence.get_part_params()[2]) > largest_order:
                    largest_order = int(sequence.get_part_params()[2])
            except:
                pass
            
            # Check 1stEmpty
            if sequence.get_part_params()[0] == 0:
                line = orig_line
            else:
                line = orig_1stEmpty_line

            line = line.replace('[Part]', str(base))
            # Sort order
            line = line.replace('[so]', str(sequence.get_part_params()[2]))
            line = line.replace('[tmo]', str(sequence.get_part_params()[1]))
            # Crop bounds
            crop_bounds_str = sequence.get_crop_bounds()
            crop_bounds = crop_bounds_str.split(",")
            try:
                row_start = int(crop_bounds[0])
                col_start = int(crop_bounds[1])
                row_end = int(crop_bounds[2])
                col_end = int(crop_bounds[3])
            except:
                messagebox.showerror("Invalid crop bound", "Invalid crop bound {}".format(crop_bounds_str))
                continue

            sx = (col_end - col_start)/2
            sy = (row_end - row_start)/2
            px = (sx + col_start)/2
            py = 802.5-(sy + row_start)/2
            line = line.replace('[sx]', str(sx))
            line = line.replace('[sy]', str(sy))
            line = line.replace('[px]', str(px))
            line = line.replace('[py]', str(py))


            
            glosses = self.gloss_files()
            # Number of Glosses
            if sequence.get_part_params()[0] == 0:
                line = line.replace('[NumberOfGloss]', str(len(glosses)))
            else:
                line = line.replace('[NumberOfGloss]', str(len(glosses)+1))
                
            for i in range(20):
                if i < len(glosses):
                    line = line.replace('Tab{:02d}'.format(i+1), glosses[i])
                else:
                    line = line.replace('Tab{:02d}'.format(i+1), "")
            lines += line

        # Set the background order
        end = end.replace('[order]', str(largest_order))
        # Glue the parts together
        output = start + lines + end
        file_out =  os.path.join(self.get_output_dir(),
                                 self.get_model_name(),
                                 self.get_model_name() + '_Parts.csv')
        with open(file_out, 'w') as f:
            f.write(output)
            
        
    def gloss_files(self):
        directory = os.path.join(self.get_output_dir(),
                                 self.get_model_name(),
                                 self.get_model_name() + '_UI',
                                 'Tab')
        files = os.listdir(directory)
        gloss_files = []
        for file in files:
            if (not 'PAT' in file) and (not 'BG' in file) and (not 'Glass' in file):
                gloss_files.append(file.replace('.png',''))

        gloss_files.sort()
        return gloss_files
    
        
    def run_macro2(self):
        self.set_script2_message("Running", "green")

        # Run crop all to the sequence folders
        directory = self.get_directory()
        for base, sequence in self.get_mask_sequences().items():
            crop_bounds_str = sequence.get_crop_bounds()
            crop_bounds = crop_bounds_str.split(",")
            try:
                row_start = int(crop_bounds[0])
                col_start = int(crop_bounds[1])
                row_end = int(crop_bounds[2])
                col_end = int(crop_bounds[3])
            except:
                messagebox.showerror("Invalid crop bound", "Invalid crop bound {}".format(crop_bounds_str))
                continue

            input_dir = os.path.join(directory,
                                     sequence.get_folder())
            images = glob.glob(input_dir+"/*.png")
            for i in range(len(images)):
                self.set_script2_message("In "+base+" cropping file "+str(i+1)+" of "+str(len(images)), "green")
                image = images[i]
                try:
                    orig = misc.imread(image)
                except:
                    print("Could not open "+image)
                    continue
                shape = np.shape(orig)
                # Save the cropped image
                if shape[0] < row_end or shape[1] < col_end:
                    continue
                try:
                    misc.imsave(image, orig[row_start:row_end,col_start:col_end])
                except:
                    print("Could not save "+image)
                    continue

        # For each mask, process all the source images with the same index
        i = 0
        tot = 0
        for base, sequence in self.get_mask_sequences().items():
            tot += len(sequence.get_images()) * len(self.get_source_sequences())

        for base, sequence in self.get_mask_sequences().items():
            input_dir = os.path.join(directory,
                                     sequence.get_folder())
            for index, mask_name in sequence.get_images().items():
                mask = misc.imread(os.path.join(input_dir, os.path.basename(mask_name)), flatten=True)
                # Get all the source images
                for source_base, source_sequence in self.get_source_sequences().items():
                    if index in source_sequence.get_images():
                        image_name = source_sequence.get_images()[index]
                        image = misc.imread(os.path.join(input_dir, os.path.basename(image_name)))
                        shape = np.shape(image)
                        # Run cutout
                        self.set_script2_message("Running cutout "+str(i+1)+" of "+str(tot), "green")
                        i += 1
                        if Sequence.gloss(image_name):
                            new = 255* np.ones((shape[0], shape[1], 4))
                            new[:,:,3] = self.rgb_to_gray(image)* mask/255.0
                        else:
                            new = np.zeros((shape[0], shape[1], 4))
                            new[:,:,0:3] = image[:,:,0:3]
                            new[:,:,3] = mask

                        # save the new file
                        new_name = base + "_" + source_base + "." +  str(index) + ".png"
                        try:
                            misc.imsave(os.path.join(input_dir, new_name), new)
                        except:
                            print("Could not save "+new_name)

        # Delete the process files
        self.set_script2_message("Cleaning up...", "green")
        for base, sequence in self.get_mask_sequences().items():
            input_dir = os.path.join(directory,
                                     sequence.get_folder())
            for index, mask_name in sequence.get_images().items():
                os.unlink(os.path.join(input_dir, os.path.basename(mask_name)))
            for source_base, source_sequence in self.get_source_sequences().items():
                for index, image_name in source_sequence.get_images().items():
                    os.unlink(os.path.join(input_dir, os.path.basename(image_name)))
        
        self.generate_crop_bound_report()

        self.set_script2_message("Finished", "green")

    def generate_crop_bound_report(self):
        self.report = ""
        for base, sequence in self.get_mask_sequences().items():
            crop_bounds_str = sequence.get_crop_bounds()
            crop_bounds = crop_bounds_str.split(",")
            try:
                row_start = int(crop_bounds[0])
                col_start = int(crop_bounds[1])
                row_end = int(crop_bounds[2])
                col_end = int(crop_bounds[3])
            except:
                print('Could not report crop bounds {}'.format(base))
                continue
            
            self.report += base+"\n"
            self.report += ",Top,{}\n".format(row_start)
            self.report += ",Left,{}\n".format(col_start)
            self.report += ",Bottom,{}\n".format(row_end)
            self.report += ",Right,{}\n".format(col_end)

        self.save_crop_report()
            
    def save_crop_report(self):
        try:
            with open(os.path.join(self.get_directory(), "crop_report.csv"), "a") as f:
                f.write(self.report)
        except:
            print("Could not save csv")




    def copy_images(self):
        out_path = os.path.join(self.get_output_dir(),
                                       self.get_model_name(),
                                       self.get_model_name() + '_Model -HD')
        
        for base, sequence in self.get_mask_sequences().items():
            size = sequence.get_power_of_two_size()
            path = os.path.join(self.get_directory(),
                                base)
            images = os.listdir(path)
            for image in images:
                self.set_script8_message("Resampling HD image {}".format(image), "green")

                orig = misc.imread(os.path.join(path, image))
                resampled = misc.imresize(orig, (int(size[0]), int(size[1])), interp=self.interpolation_method.get())
                misc.imsave(os.path.join(out_path,
                                         image), resampled)

        # SD Images
        out_path = os.path.join(self.get_output_dir(),
                                       self.get_model_name(),
                                       self.get_model_name() + '_Model -SD')
        
        for base, sequence in self.get_mask_sequences().items():
            size = sequence.get_power_of_two_size()
            path = os.path.join(self.get_directory(),
                                base)
            images = os.listdir(path)
            for image in images:
                self.set_script8_message("Resampling SD image {}".format(image), "green")

                orig = misc.imread(os.path.join(path, image))
                resampled = misc.imresize(orig, (int(int(size[0])/2), int(int(size[1])/2)), interp=self.interpolation_method.get())
                misc.imsave(os.path.join(out_path,
                                         image), resampled)


        # LD Images
        out_path = os.path.join(self.get_output_dir(),
                                       self.get_model_name(),
                                       self.get_model_name() + '_Model -LD')
        for base, sequence in self.get_mask_sequences().items():
            size = sequence.get_power_of_two_size()
            path = os.path.join(self.get_directory(),
                                base)
            images = os.listdir(path)
            for image in images:
                self.set_script8_message("Resampling LD image {}".format(image), "green")

                orig = misc.imread(os.path.join(path, image))
                resampled = misc.imresize(orig, (int(int(size[0])/4), int(int(size[1])/4)), interp=self.interpolation_method.get())
                misc.imsave(os.path.join(out_path,
                                         image), resampled)

        # LD Buttons
        path = os.path.join(self.get_output_dir(),
                            self.get_model_name(),
                            self.get_model_name() + '_UI',
                            'TMenu')
        out_path = os.path.join(self.get_output_dir(),
                            self.get_model_name(),
                            self.get_model_name() + '_UI - LD',
                            'TMenu')
        images = os.listdir(path)
        for image in images:
            self.set_script8_message("Resampling LD buttons {}".format(image), "green")
            
            orig = misc.imread(os.path.join(path, image))
            resampled = misc.imresize(orig, 0.5, interp=self.interpolation_method.get())
            misc.imsave(os.path.join(out_path,
                                     image), resampled)
            
        self.set_script8_message("Done", "green")

    # uses crop report to read in data
    def read_sequences(self):
        self.set_script3_message("Reading crop report", "green")
        crop_report_file = os.path.join(self.get_directory(), 'crop_report.csv')
        try:
            with open(crop_report_file, 'r') as f:
                lines = f.readlines()

            # Parse the data
            seq = None
            for line in lines:
                split_line = line.replace('\n', '').split(',')
                if len(split_line) == 1:
                    if seq != None:
                        seq.set_crop_bounds(','.join(crop_bounds))
                        self.add_mask_sequence(seq)
                    crop_bounds = []
                    base = split_line[0]
                    if self.mask_sequence_exists(base):
                        seq = self.get_mask_sequence(base)
                    else:
                        # Create a new one
                        seq = Sequence()
                        seq.set_base(split_line[0])
                else:
                    crop_bounds.append(split_line[-1])

            # last sequence
            if seq != None:
                seq.set_crop_bounds(','.join(crop_bounds))
                self.add_mask_sequence(seq)
                
            self.set_script3_message("Done", "green")

        
        except Exception as e:
            logging.error("Error {} occured.".format(e))
            logging.warning("Could not open crop report file")
            self.set_script3_message("Error while reading crop report", "red")

        
    def rgb_to_gray(self, rgb):
        return np.dot(rgb[...,:3], [0.299, 0.587, 0.114])

    def copy_model_folder_structure(self):
        with ZipFile('model.zip') as myzip:
            myzip.extractall(path=self.get_output_dir())
        # Rename
        while(self.rename_by_model()):
            pass
        
        
        
    def rename_by_model(self):
        directory = self.get_output_dir()
        pattern = '[MODELNAME]'
        for path, dirs, files in os.walk(os.path.abspath(directory)):
            for filename in dirs + files:
                if pattern in filename:
                    src = os.path.join(path, filename)
                    dst = os.path.join(path, filename.replace(pattern, self.get_model_name()))
                    shutil.move(src, dst)
                    return True
                
        return False
    
    def copy_to_all_mask_folders(self, src):
        directory = self.get_directory()
        for base, sequence in self.get_mask_sequences().items():
            dst = os.path.join(directory,
                               sequence.get_folder(),
                               os.path.basename(src))
            # Copy
            try:
                shutil.copyfile(src, dst)
            except:
                print("Could not copy file")
                
    def run_macro1(self):
        self.set_script1_message("Running", "green")

        # Update the directory
        self.set_directory(self.directory_entry.get())
        directory = self.get_directory()

        input_dir = os.path.join(directory,"Z_MATTE")
        if not self.validate_dir(input_dir):
            messagebox.showerror("Invalid directory", "Invalid directory {}".format(input_dir))
            return

        self.init_sequences()
        # Scan input directory and generate sequence objects and corresponding folders
        images = glob.glob(input_dir+"/*.png")
        for i in range(len(images)):
            self.set_script1_message("Scanning file "+str(i+1)+" of "+str(len(images)), "green")
            image = images[i]

            # Check if Sequence exists
            base = Sequence.parse_base(image)
            if self.mask_sequence_exists(base):
                sequence = self.get_mask_sequence(base)
                sequence.add_image(image)
            else:
                # Create a new one
                sequence = Sequence(image)
                self.add_mask_sequence(sequence)
                # Create a folder
                if not os.path.exists(os.path.join(directory,
                                                   sequence.get_folder())):
                    try:
                        os.makedirs(os.path.join(directory,
                                                 sequence.get_folder()))
                    except:
                        print("Could not create directory")

            # Copy the image into the folder
            try:
                src = os.path.join(input_dir, os.path.basename(image))
                dst = os.path.join(directory, sequence.get_folder(), os.path.basename(image))
                shutil.copyfile(src, dst)
            except:
                print("Could not copy file")
        # Run crop analysis for the mask sequence folders
        for base, sequence in self.get_mask_sequences().items():
            #images = list(sequence.get_images().values())
            images = glob.glob(os.path.join(directory, sequence.get_folder())+"/*.png")
            for i in range(len(images)):
                self.set_script1_message("In "+base+" processing file "+str(i+1)+" of "+str(len(images)), "green")
                image = misc.imread(images[i], flatten=True)

                if i == 0:
                    reference_shape = np.shape(image)
                    result = np.zeros(reference_shape)

                result = np.logical_or(result, image)

            try:
                nonzeros = np.nonzero(result)
                row_start = min(nonzeros[0])
                col_start = min(nonzeros[1])
                row_end = max(nonzeros[0])
                col_end = max(nonzeros[1])
            except:
                self.set_script1_message("Error occured, check input values ", "red")

            #crop_bounds = "{},{},{},{}".format(row_start, col_start, row_end+1, col_end+1)
            #print("orig crop bounds {}".format(crop_bounds))
            #print("resuting image size {}, {}".format(row_end - row_start+1, col_end - col_start+1))
            # Add one pixel "bleed in all directions"
            if row_start > 0:
                row_start -= 1
            if row_end < reference_shape[0]:
                row_end += 1
            if col_start > 0:
                col_start -= 1
            if col_end < reference_shape[1]:
                col_end += 1

            # Make crop size even
            if (row_end - row_start + 1)%2:
                if row_start > 0:
                    row_start -= 1
                elif row_end < reference_shape[0]:
                    row_end += 1
                else:
                    self.set_script1_message("Error occured, can't make it even!", "red")
            if (col_end - col_start + 1)%2:
                if col_start > 0:
                    col_start -= 1
                elif col_end < reference_shape[1]:
                    col_end += 1
                else:
                    self.set_script1_message("Error occured, can't make it even!", "red")
                    
                    
            
            crop_bounds = "{},{},{},{}".format(row_start, col_start, row_end+1, col_end+1)
            #print("new crop bounds {}".format(crop_bounds))
            #print("resuting image size {}, {}".format(row_end - row_start + 1, col_end - col_start+1))
            
            
            sequence.set_crop_bounds(crop_bounds)


        # Scan source Z_SOURCE sequences
        input_dir = os.path.join(directory,"Z_SOURCE")
        # Scan input directory and generate sequence objects and corresponding folders
        images = glob.glob(input_dir+"/*.png")
        
        for i in range(len(images)):
            self.set_script1_message("Scanning file "+str(i+1)+" of "+str(len(images)), "green")
            image = images[i]
            # Check if Sequence exists
            base = Sequence.parse_base(image)
            if self.source_sequence_exists(base):
                sequence = self.get_source_sequence(base)
                sequence.add_image(image)
            else:
                # Create a new one
                sequence = Sequence(image)
                self.add_source_sequence(sequence)

            # Copy the image to all mask folders
            src = os.path.join(input_dir, os.path.basename(image))
            self.copy_to_all_mask_folders(src)
                

        # Script finished
        self.set_script1_message("Finished", "green")
        CropAnalysisResults(self)
        
        
    def set_script1_message(self, text, color):
        self.script1_message['text'] = text
        self.script1_message['foreground'] = color
        self.update()
        
        
    def set_script2_message(self, text, color):
        self.script2_message['text'] = text
        self.script2_message['foreground'] = color
        self.update()
        
    def set_script3_message(self, text, color):
        self.script3_message['text'] = text
        self.script3_message['foreground'] = color
        self.update()
        
    def set_script30_message(self, text, color):
        self.script30_message['text'] = text
        self.script30_message['foreground'] = color
        self.update()
        
    def set_script4_message(self, text, color):
        self.script4_message['text'] = text
        self.script4_message['foreground'] = color
        self.update()
        
    def set_script5_message(self, text, color):
        self.script5_message['text'] = text
        self.script5_message['foreground'] = color
        self.update()
        
    def set_script6_message(self, text, color):
        self.script6_message['text'] = text
        self.script6_message['foreground'] = color
        self.update()
        
    def set_script7_message(self, text, color):
        self.script7_message['text'] = text
        self.script7_message['foreground'] = color
        self.update()
        
    def set_script8_message(self, text, color):
        self.script8_message['text'] = text
        self.script8_message['foreground'] = color
        self.update()
        
        
    def update_gui(self):
        self.update_directory_message()
        self.update()
        


        
root = tk.Tk()
app = MacroPhytoshop(master=root)
app.mainloop()
